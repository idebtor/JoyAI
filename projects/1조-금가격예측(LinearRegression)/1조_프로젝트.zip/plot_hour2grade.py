
import matplotlib.pyplot as plt  
%matplotlib inline
# 그리고 그래프를 출력하기 위해 맷플랏라이브러리를 불러왔습니다.
